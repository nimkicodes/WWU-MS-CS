[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/CQV6MuFv)
[![Open in Codespaces](https://classroom.github.com/assets/launch-codespace-2972f46106e565e64193e422d61a12cf1da4916b45550586e14ef0a7c637dd04.svg)](https://classroom.github.com/open-in-codespaces?assignment_repo_id=17766440)
# CSCI 447 - Operating Systems  
## A1: Programming Assignment - First KPL and Assembly Program  
**Individual Work**  

Your homework submissions for this and all future homework assignments must be your own. You may discuss topics and concepts at a high level with other students, but you cannot share, co-author, or view other students' code. If any of this is unclear, please ask for further clarification.

### Overview and Goal  
This programming assignment is an extension of Lab 1. Complete Lab 1 prior to starting this coding homework.

## Coding Task  

This single coding task serves as a refresher on C and assembly code, which you must write.

1. **Create a New Branch:**  
   Create a new branch on your GitHub repository for this class. Name the branch `homework1`.

2. **Branch Setup:**  
   Checkout the new `homework1` branch. All work for this homework assignment should be done in the `homework1` branch.

3. **Modify Runtime.s:**  
   Add a new function, `GetCh`, to `Runtime.s`. The function should accept no arguments, read a character from input, and return the character received (either as a char, int, or other suitable type). See `Echo.s` for examples of code for writing functions.

4. **Update System.h:**  
   Add the external definition for `GetCh` to `System.h`. Ensure you export the new function in `Runtime.s`.

5. **Create aFunProgram.k:**  
   Write a new program, `aFunProgram.k`, which implements the same “echo” behavior as the `Echo.s` program, using the function `GetCh`. If a user inputs `q` as the first (or only) character and presses enter, the program should stop and the debugger should be invoked. For any input other than `q`, the program should echo the character(s) input by the user and continue running in non-debugger mode, waiting for the next prompt.  

   *Hint:* Read the code for `getCatchStack()` in `Runtime.s` to understand how to return data as a function value.

6. **Update Makefile:**  
   Modify the `Makefile` to ensure that when `make` is invoked from the command line, the `aFunProgram` executable is created.

7. **Demonstrate Program Execution:**  
   Create a transcript of a terminal session demonstrating the use of your program, `aFunProgram`. Name this file `homework1-script` or `homework1-script.txt`.

8. **Commit and Push Changes:**  
   Add, commit, and push your new file and changes to existing files, along with the script, to the `homework1` branch of your GitHub repository.

## Rubric  

| Task | Description | Points |
|------|-------------|--------|
| Setup | Git branch created correctly, no `.o` files or `aFunProgram` pushed to Git | 10 |
| Function Implementation | `GetCh` written with return value, commented, added to `Runtime.s`, and declared in `System.h` | 15 |
| Program Implementation | `aFunProgram.k` written with comments, uses `GetCh` to mimic `Echo.s` behavior | 15 |
| Script | Demonstration script file created and uploaded | 10 |
| Makefile | Makefile correctly updated | 10 |
| Program Behavior | `aFunProgram` runs correctly and jumps into debug mode only if `q` is the first character typed | 20 |
| **Total** | | **80 points** |
