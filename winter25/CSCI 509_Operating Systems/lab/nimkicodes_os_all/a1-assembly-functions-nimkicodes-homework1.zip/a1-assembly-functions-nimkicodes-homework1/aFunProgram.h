header aFunProgram
    uses System

    functions
      main()
        
endHeader