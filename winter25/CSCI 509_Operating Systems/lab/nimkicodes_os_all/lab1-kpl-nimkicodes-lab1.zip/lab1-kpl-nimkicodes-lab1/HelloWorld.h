header Hello
  uses System

  functions
    main ()

endHeader
