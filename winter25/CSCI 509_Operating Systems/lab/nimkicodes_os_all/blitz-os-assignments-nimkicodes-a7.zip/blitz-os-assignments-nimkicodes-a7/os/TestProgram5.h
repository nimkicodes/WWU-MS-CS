header TestProgram5
 
  uses UserSystem

  functions
    main ()

endHeader
