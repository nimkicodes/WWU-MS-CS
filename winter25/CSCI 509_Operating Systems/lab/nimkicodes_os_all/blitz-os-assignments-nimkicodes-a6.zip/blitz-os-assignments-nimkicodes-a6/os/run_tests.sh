# !/bin/bash
# all the test need to be commented out in TestProgram4.k
TESTS=(
  "OpenTest1"
  "OpenTest2"
  "OpenCloseTest"
  "CloseTest1"
  "CloseTest2"
  "ReadTest1"
  "ReadTest2"
  "SeekTest"
  "WriteTest1"
  "WriteTest2"
  "WriteTest3"
  "WriteTest4"
  "WriteTest5"
  "ReadTest3"
  "ReadTest4"
  "WriteTest6"
  "OpenTest3"
  "ExecTest1"
  "ExecTest2"
  "ExecTest3"
  "StatTest"
  "ChDirTest"
  "OpenTest4"
  "WriteTestExtend"
  "ErrorTests"
  "ExecTestPermissions"
  "OpenTestPermissions"
  "OpenTestCreateFile"
)
cp TestProgram4.k TestProgram4.k.orig
for test in "${TESTS[@]}"; do
  
  make realclean > /dev/null

  # Modify TestProgram4.k to uncomment the current test
  cat TestProgram4.k.orig | sed "s/-- $test ()/$test ()/" > TestProgram4.k
  
  make > /dev/null
  make TestProgram4 > /dev/null

  blitz os -g 
done
mv TestProgram4.k.orig TestProgram4.k
echo "All tests completed!\n"