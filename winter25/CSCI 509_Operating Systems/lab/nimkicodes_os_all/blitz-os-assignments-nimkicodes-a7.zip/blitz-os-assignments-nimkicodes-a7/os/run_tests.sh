# !/bin/bash
# all the test need to be commented out in TestProgram5.k
TESTS=(
  "OpenAndReadDirTest"
  "DupTest"
  "PipeTest"
  "ChModeTest"
  "LinkTest"
  "UnlinkTest"
)
cp TestProgram5.k TestProgram5.k.orig
for test in "${TESTS[@]}"; do
  
  make realclean > /dev/null

  # Modify TestProgram5.k to uncomment the current test
  cat TestProgram5.k.orig | sed "s/-- $test ()/$test ()/" > TestProgram5.k
  
  make > /dev/null
  make TestProgram5 > /dev/null

  blitz os -g 2> /dev/null
  
done
mv TestProgram5.k.orig TestProgram5.k
echo "All tests completed!\n"