[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/8KIkH1Dc)
[![Open in Codespaces](https://classroom.github.com/assets/launch-codespace-2972f46106e565e64193e422d61a12cf1da4916b45550586e14ef0a7c637dd04.svg)](https://classroom.github.com/open-in-codespaces?assignment_repo_id=17699771)
<div align="center">
CSCI 447 - Operating Systems
Lab 1 : Introduction to the BLITZ Tools, kpl, makefile, etc.
</div>

# Lab and Homework Assignments

You may work together to complete the labs, but each person must have
their own submission. Homework assignments, however, must be completed,
debugged, and uploaded individually.

# Overview and Goal

This lab introduces you to several of the BLITZ tools that you'll be
using throughout the term to complete lab and homework assignments.
BLITZ was designed specifically for writing a small OS kernel, and was
developed by Harry H. Porter at Portland State University. The tools
have been modified for use here at WWU. *Do not use the original tools.*
Both executables for the Linux cluster and source code are provided to
you so you can install BLITZ on your machine if you so choose.
Sections 1-5 pertain to BLITZ setup, and
Section 6 onward
is the lab. Submission instructions and the rubric are the last
section.
Throughout this (and future) labs, as well as homework assignment
instructions, text that is provided in a box is instructing you to issue
verbatim one or more commands via the command line. For example, the
following is instructing you to issue the command `whoami` on the
command line :

# The Documentation
Documents describing the BLITZ tools are available on Canvas.

1.  An Overview of the BLITZ System (7 pages)

2.  An Overview of the BLITZ Computer Hardware (8 pages)

3.  The BLITZ Architecture (71 pages)

4.  Example BLITZ Assembly Program (7 pages)

5.  BLITZ Instruction Set (4 pages)

6.  The BLITZ Emulator (44 pages)

7.  An Overview of KPL, A Kernel Programming Language (66 pages)

8.  Context-Free Grammar of KPL (7 pages)

9.  BLITZ Tools: Help Information (13 pages)

10. The Format of BLITZ Object and Executable Files (12 pages)

# Read the Overview Document

Read the first document, An Overview of the BLITZ System, before
proceeding.

# BLITZ hosting and tools

You will develop your operating system code on a host computer and you
will be running the BLITZ tools on that host computer. BLITZ has been
installed on the department's Linux systems, and your code submissions
will be run (and tested) there. The BLITZ tool set is made up of the
following components:

1.  The KPL compiler

2.  The BLITZ assembler

3.  The BLITZ linker

4.  The BLITZ machine emulator (the virtual machine and debugger)

5.  A utility to manipulate the simulated BLITZ DISK file

6.  A utility to print BLITZ .o and a.out files

7.  A utility to print any file in hex

8.  A utility to run through a file looking for problem ASCII characters

9.  A utility to determine if this machine is Big or Little Endian

These tools are listed more-or-less in the order they would be used. You
will probably only need to use the first 4 or 5 tools and you may pretty
much ignore the remaining tools. The last three tools are only
documented by the comments at the beginning of the source code files,
which you may read if interested.

# Setup for use

The Blitz executables are available on the department Ubuntu Linux
machines in Tarek's directory at the following location: `/home/idrisst/blitz`
So that you can invoke the tools (programs) from the command line from
any of your directories, add the above bin location to your PATH
variable in your login shell "rc" file. For bash, the file name is
*.profile*, and you may need to create one if the file doesn't exist
yet. In case you have never added anything to your path before, edit or
create the *.profile* file in your home directory (assuming you are
using bash). For example, placing the following line at the end of your
*.profile* file will make your shell look for commands in the blitz bin
directory:

         export PATH=$PATH:/home/idrisst/blitz

After you edit your *.profile* file, you need to logout and log back in,
or instruct your shell to read/process the new contents of the
*.profile* file by issuing the `source` command :

To verify that you modified the PATH variable correctly, issue the `kpl`
command from a prompt:

You should see the following:

        *****  ERROR: Missing package name on command line

        **********  1 error detected!  **********

If you see anything else, then something is wrong. Ask for help if you
have any questions.

# Running BLITZ on your own computer

If you are working anywhere in your directory tree on the WWU linux
machines, and you don't want to install BLITZ on your own computer, skip
this section.

The BLITZ tools can run on any linux OS that supports 32-bit execution
If you want to compile your own copy of the BLITZ tools on your own
computer, the source code for all the BLITZ tools is available at Canvas
under BLITZ Resources module. The following steps are for installing and
running BLITZ on your own machine.

-   Download the source tar ball to your machine. (see above for
    location)

-   Extract the tar ball.

-   Modify the "makefile" and set the make variable BINDIR to where you
    want your blitz tools installed.

-   The command "make install" will make and install the tools.

-   Change your PATH environment variable to include the value you put
    in the BINDIR definition.

# Set up a GitHub Classroom repository for 447 assignment turn-in

During this quarter, you will be turning in your code assignments via **GitHub Classroom**, a platform that simplifies submission management using Git. Git is a powerful version control system widely used in both academia and industry. Many online resources are available detailing useful git commands and functions. Some of the key git commands you'll use include *branch, push, pull, commit,* and *add*. If you are unfamiliar with git, refer to the official [Git documentation](https://git-scm.com/) and the [Git cheat sheet](https://github.github.com/training-kit/downloads/github-git-cheat-sheet.pdf).

Follow the steps below to set up your GitHub repository for this course:

1. **Accept the GitHub Classroom Assignment**:
   - You will receive a link to the assignment via Canvas or email. Click the link to accept the assignment.
   - Upon accepting, GitHub Classroom will automatically create a private repository for you with the appropriate naming convention (e.g., `csci447_F24_<your-github-username>`). You do not need to create the repository manually.

2. **Access your repository**:
   - Once the repository is created, you can access it through your GitHub account. All repositories are private, and I will automatically have access to review and retrieve your submissions, so you do not need to manually add me as a collaborator.

3. **Clone your repository**:
   - From the command line, `clone` your newly created repository to your local working directory. The clone URL can be found on your GitHub repository page. Use the following command:
     ```bash
     git clone <clone-url>
     ```
   - If you're unsure about git commands, consult the resources provided or ask for help.

4. **Keep the `main` branch intact**:
   - The `main` branch contains the original handout code. Do **not** modify the `main` branch. You will use it as a reference for the original code if needed.

5. **Create and checkout a new branch for your work**:
   - Create a new branch to work on your lab. For this lab, create a branch called `lab1`:
     ```bash
     git checkout -b lab1
     ```
   - Do **all** of your work in this `lab1` branch, keeping the `main` branch intact for reference. You can switch back to `main` at any time to review the original code.

6. **Set up your lab files**:
   - In your `lab1` branch, create a directory named `lab1` in your local repository, and place the untarred files from the Lab1 tarball (available on Canvas) into that directory. The files should include `DISK`, `*.s`, `*.h`, `*.k`, and the `makefile`.

7. **Check the status of your changes**:
   - Before pushing code, inspect the changes made to your local files by running the `status` command:
     ```bash
     git status
     ```

8. **Add and commit your changes**:
   - Add the `lab1` directory and its contents to your git repository:
     ```bash
     git add lab1/
     git commit -m "Added lab1 files"
     ```

9. **Push the `lab1` branch to GitHub**:
   - Push the `lab1` branch to the remote GitHub repository:
     ```bash
     git push origin lab1
     ```

10. **Switching back to the `main` branch**:
    - If you need to refer to the original code at any point, switch back to the `main` branch without affecting your work:
      ```bash
      git checkout main
      ```
    - After reviewing the `main` branch, you can switch back to your working `lab1` branch:
      ```bash
      git checkout lab1
      ```

11. **Work on the `lab1` branch**:
    - Continue working on the `lab1` branch for the remainder of this lab. Make sure all your updates are committed and pushed to this branch.

**IMPORTANT**: By convention, do not push executable (binary), object (.o), or any other non-text files to the repository. These files are system-dependent and can unnecessarily bloat the repository. Only source code files and plain-text files should be added to your repo.


# The BLITZ Assembly Language

In this course you are not required to write (much) assembly language
code, but you will have to write some for this lab (and perhaps homework
1). However, you will be using some interesting routines which can only
be written in assembly. Most if not all assembly language routines will
be provided to you, but you will need to be able to read them.

Take a look at the files *Echo.s* and *Hello.s* to see what BLITZ
assembly code looks like.

# Assemble, Link, and Execute the *Hello* Program

The files you've downloaded contain an assembly language program called
*Hello.s*. First invoke the assembler (the tool called `asm`) to
assemble the program:

This should produce no errors and should create a file called *Hello.o*.
The Hello.s program is completely stand-alone; it does not need any
library functions and does not rely on any operating system.
Nevertheless, it must be linked to produce an executable (an *a.out*
file). The linking is done with the tool called `lddd`. (In UNIX, the
linker is called "ld".)

By default, the executable is named *a.out*, but the "-o Hello" option
specifies that the executable should be named *Hello*. Execute the
program, using the BLITZ virtual machine (emulator):

The `-g` option is the "auto-go" option and it means begin execution
immediately. You should see:

      Beginning execution...
      Hello, world!

      ****  A 'debug' instruction was encountered  *****
      Done!  The next instruction to execute will be:
      000080: A1FFFFB8       jmp     0xFFFFB8         ! targetAddr = main

      Entering machine-level debugger...
      ======================================================
      =====                                            =====
      =====         The BLITZ Machine Emulator         =====
      =====                                            =====
      =====  Copyright 2001-2007, Harry H. Porter III  =====
      =====                                            =====
      ======================================================

      Enter a command at the prompt.  Type 'quit' to exit or 'help' for
      info about commands.
      >

At the prompt, quit and exit by typing "q" (short for quit). You should
see this:

      > q
      Number of Disk Reads    = 0
      Number of Disk Writes   = 0
      Instructions Executed   = 1705
      Time Spent Sleeping     = 0
          Total Elapsed Time  = 1705

This program terminates by executing the debug machine instruction. This
instruction causes the emulator to stop executing instructions and
throws the emulator into command mode. In command mode, you can enter
commands, such as quit. The emulator displays the character "$>$" as a
prompt.

After the debug instruction, the Hello program branches back to the
beginning. Therefore, if you resume execution (with the go command), it
will result in another printout of "Hello, world!".

# A second BLITZ assembly code example, *Echo*

Another assembly language program has been provided for you, named Echo.
All that it does is listen to the keyboard, and echoes the typed keys
back to the monitor. Inspect the *Echo.s* file. To assmble, link, and
run the program :

On the last line, we have left out the auto-go `-g` option. Now, the
BLITZ emulator will not automatically begin executing; instead it will
enter command mode. When it prompts, type the "g" command (short for
"go") to begin execution. Type some text. Each time the ENTER/RETURN key
is pressed, you should see the output echoed. For example:

        > g
        Beginning execution...
        abcd
        abcd
        this is a test
        this is a test
        q
        q
        ****  A 'debug' instruction was encountered  *****
        Done!  The next instruction to execute will be:
                           cont:
        0000A4: A1FFFFAC       jmp   0xFFFFAC       ! targetAddr = loop
        > 

This program watches for the "q" character and stops when it is typed.
If you resume execution with the go command, this program will continue
echoing whatever you type. The Echo program is also a stand-alone
program, relying on no library functions and no operating system.

# The KPL Programming Language

In this course, you will write code in the KPL programming language. In
preparation for homework 1, begin studying the document titled *An
Overview of KPL: A Kernel Programming Language,* which is one of the 10
documentation files for BLITZ made available for you. Should you read
the entirety of that document, word-for-word? No. Should you be familiar
with the contents, so that you may use that file as a reference? Yes.

## Compile and Execute a KPL Program called HelloWorld

The *HelloWorld.k* and *HelloWorld.h* files are being provided for you.
Inspect them. These contain the equivalent of the program code (.cpp,
.c) and header (.h) for `C++` and `C`. Note that the original Blitz/KPL
system used .c files for code, but the compiler has been changed at WWU
to use the .k suffix so these files are not confused with C programs by
tools like emacs.
Type the following commands to compile and link the HelloWorld program:

There should be no error messages.
The HelloWorld program makes use of some other code, which is contained
in the files *System.h* and *System.k*. These must be compiled with the
`-unsafe` option. If you leave that out, you'll get 17 compiler error
messages, such as:

        System.h:39: *****  ERROR at PTR: Using 'ptr to void' is unsafe;
                            you must compile with the 'unsafe' option
                            if you wish to do this

Using the UNIX compiler convention, this means that the compiler
detected an error on line 39 of file *System.h*.

KPL programs are often linked with routines coded in assembly language.
Right now, all the assembly code we need is included in a file called
*Runtime.s*. Basically, the assembly code takes care of:

-   Starting up the program

-   Dealing with runtime errors, by printing a message and aborting

-   Printing output (There is no mechanism for input at this stage...
    This system really needs an OS!)

Now execute this program. Type:

You should see the "Hello, world..." message. What happens if you type
"g" at the prompt, to resume instruction execution?

## The "makefile"

The lab1 directory contains a file called makefile, which is used with
the UNIX `make` command. Whenever a file in the lab1 directory is
changed, you can type "make" to re-compile, re-assemble, and re-link as
necessary to rebuild the executables. Notice that the following command
:

will be executed whenever the file *System.h* is changed. Each package
(such as HelloWorld) will have both a header file and a code file. The
HelloWorld package uses the System package. Whenever the header file of
a package that HelloWorld uses is changed, HelloWorld must be
recompiled. However, if the code file for System is changed, you do not
need to recompile HelloWorld. You only need to re-link (i.e., you only
need to invoke lddd to produce the executable).

Consult the KPL documentation for more info about the separate
compilation of packages.

## Modify the HelloWorld Program

To get more practice, modify the *HelloWorld.k* program by un-commenting
the following line:

        --foo (10)

In KPL, comments are "--" through end-of-line. Simply remove the hyphens
and recompile as necessary, using "make". The *foo* function calls
*bar*. The *bar* function does the following things:

-   Increment its argument

-   Print the value

-   Execute a "debug" statement

-   Recursively call itself

When you run the modified HelloWorld program it will print a value and
then halt. The keyword *debug* in the code is a statement that will
cause the emulator to halt execution. **Hint: In later assignments, you
will probably want to place *debug* in programs you write when you are
debugging, so you can stop execution and look at variables.**

If you type the go command, the emulator will resume execution. It will
print another value and halt again. Type go several times, causing bar
to call itself recursively several times. Then try the st command (st is
short for "stack"). This will print out the execution stack. Try the fr
command (short for "frame"). You should see the values of the local
variables in some activation of bar.

Try the up and down commands. These move around in the activation stack.
You can look at different activations of bar with the fr command.

## Try Some of the Emulator Commands

Try the following commands to the emulator, where abbreviations are
shown in parentheses:

-   quit (q)

-   help (h)

-   go (g)

-   step (s)

-   t

-   reset

-   info (i)

-   stack (st)

-   frame (fr)

-   up

-   down

The "step", `st`, command will execute a single machine-language
instruction at a time. You can use it to walk through the execution of
an assembly language program, line-by-line.

The `t` command will execute a single high-level KPL language statement
at a time. Try typing "t" several times to walk through the execution of
the HelloWorld program. See what gets printed each time you enter the
"t" command.

The `i` command (short for info) prints out the entire state of the
(virtual) BLITZ CPU. You can see the contents of all the CPU registers.
There are other commands for displaying and modifying the registers.

The `h` command (short for help) lists all the emulator commands. Take a
look at what help prints.

The `reset` command re-reads the executable file and fully resets the
CPU. This command is useful during debugging. Whenever you wish to
re-execute a program (without recompiling anything), you could always
quit the emulator and then start it back up. The reset command does the
same thing but is faster.

It is a good idea to get familiar with each of the commands listed
above; you should use them to help debug your programs.

# What to Hand In & Rubric

First, make sure you have committed all your changes, including the
modified HelloWorld.k file, to the *lab1* branch of your git repository
on gitlab. Next, create a transcript of a terminal session showing you
using the BLITZ system. You should at least run the echo program, as
well as the modified HelloWorld program. If you do not know about
creating a script file, you can learn about the UNIX `script` command by
accessing the manual page for it:

Note that if you try to use a text editor while running script, a bunch
of garbage characters may be put into the file. Please do not do this.
Name your script file *lab1-script* or *lab1-script.txt*, and add it to
your *lab1* branch. Don't forget to commit that file and push it to your
*lab1* branch. It is a good idea to use the web interface at
gitlab.cs.wwu.edu to verify you have the correct files on the gitlab
server as that is where they will be retrieved for grading.

<div align="center">

# Rubric
| Criteria                                                                                                                     |Points     |
|:---------------------------------------------------------------------------------------------------------------------------|:----------|
| The *README* file has been created and pushed to the master branch                                               | 4         |
| branch *lab1* created, and files have been pushed to the it; .o, and/or binary files, are NOT pushed to the git  | 4         |
| HelloWorld has been correctly modified and pushed to the *lab1* director | 8       |
|  A transcript, *lab1-script* or *lab1-script.txt* has been created, and pushed to the *lab1* directory                               | 4         |
| **Total**                                                                                                                      | **20** |

</div>
