header TestProgram4a

  uses UserSystem

  functions
    main()

endHeader
