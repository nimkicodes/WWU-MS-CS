header TestProgram3a
 
  uses UserSystem

  functions
    main ()

endHeader
